# Jump to docs for bevy

This is a simple Firefox addon which adds a button to jump to the current sub-crate docs when browsing docs.rs/bevy. This allows one to directly view source etc. and generally increases happiness.
